
              TYPE FOUNDRY : Feliciano Type Foundry
              FONT NAME    : Flama


          12 Styles, Design by M�rio Feliciano                                
                                                                              
          Feliciano Type Foundry is a one-man foundry run by M�rio            
          Feliciano (born 1969 in Caldas da Rainha, Portugal). He             
          began work as a graphic designer for Surf Portugal magazine         
          in 1993. In 1994 he founded his own design studio in                
          Lisbon, Secretonix. He has been heavily involved in type            
          design since.                                                       
                                                                              
          Extremely versatile, Feliciano's typefaces range from               
          contemporary display and text fonts to classic                      
          interpretations of early Spanish types. His typefaces are           
          used prominently in many Portuguese and international               
          publications, and have garnered him two TDC awards. M�rio           
          is currently the Portuguese country delegate for the ATypI,         
          Association Typographique Internationale.                           
                                                                              
          http://www.vllg.com/Feliciano/Flama/mudTyper+Weights/

